# Vela DJ Pads

Автономный DJ-контроллер с падами для **Redmi Watch 5** (Xiaomi Vela, quick app / `.rpk`).
Звуки играют прямо на часах, телефон не нужен.

## Что умеет

- 3 банка по 8 падов (сетка 2 × 4):
  - **DRUMS** — kick, snare, hat, open hat, clap, tom lo/hi, cowbell
  - **SYNTH** — bass, stab, pluck, laser, scratch, riser, crash, airhorn
  - **HOUSE** — 808 sub, rim, shaker, conga, sweep, reverse, chord, wobble
- Переключение банков, регулировка громкости, вибро-отклик, подсветка нажатого пада.
- Экран настроек (кнопка ⚙): включение/выключение вибрации и надпись
  «Сделано с помощью @MXGA_PXGA».

## Структура

```
src/
  manifest.json          # конфиг приложения
  app.ux                 # глобальный app
  pages/index/index.ux   # интерфейс падов + логика
  pages/settings/settings.ux # настройки и кредит
  common/logo.png        # иконка
  common/sounds/*.wav    # звуки падов (16 бит, моно, 22050 Гц)
tools/gen_sounds.py      # генератор звуков (синтез на чистом Python)
```

## Свои звуки

Замените файлы в `src/common/sounds/` (или поправьте `tools/gen_sounds.py` и запустите
`python3 tools/gen_sounds.py`). Список падов и имена файлов — в массиве `BANKS`
в `src/pages/index/index.ux`. Держите размер `.wav` небольшим: коротким сэмплам место на часах.

## Сборка

Нужны Node.js 18+ и [Vela JS toolkit (aiot-toolkit)](https://iot.mi.com/vela/quickapp).

```bash
npm install
npm run build      # .rpk появится в dist/
```

Для установки на часы `.rpk` нужно подписать (release-сертификат) или залить через
Xiaomi Vela IDE / режим разработчика на часах.

## Ограничения

- `@system.audio` в Vela — один аудио-плеер: новый пад обрывает предыдущий звук, наложения (полифонии) нет.
- Задержка между касанием и звуком зависит от прошивки часов.
- Код не проверялся на реальных часах — возможны правки под вашу версию Vela / toolkit.

## Лицензия

MIT
