#!/usr/bin/env python3
"""Генератор звуков для пэдов (WAV, 16 бит, моно, 22050 Гц).

Запуск из корня репозитория:  python3 tools/gen_sounds.py
Результат: src/common/sounds/*.wav
"""
import math
import os
import random
import struct
import wave

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "common", "sounds")
random.seed(7)

TAU = 2 * math.pi


def sine(p):
    return math.sin(TAU * p)


def saw(p):
    return 2.0 * (p % 1.0) - 1.0


def square(p):
    return 1.0 if (p % 1.0) < 0.5 else -1.0


def osc(dur, freq, shape=sine):
    """Осциллятор с частотой freq(t) (Гц), возвращает список семплов."""
    n = int(dur * SR)
    phase = 0.0
    out = []
    for i in range(n):
        t = i / SR
        phase += freq(t) / SR
        out.append(shape(phase))
    return out


def noise(dur):
    return [random.uniform(-1, 1) for _ in range(int(dur * SR))]


def highpass(x):
    prev = 0.0
    out = []
    for s in x:
        out.append(s - prev)
        prev = s
    return out


def lowpass(x, a=0.3):
    y = 0.0
    out = []
    for s in x:
        y += a * (s - y)
        out.append(y)
    return out


def env(x, f):
    return [s * f(i / SR) for i, s in enumerate(x)]


def mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, s in enumerate(t):
            out[i] += s
    return out


def save(name, samples, gain=0.9):
    peak = max(1e-9, max(abs(s) for s in samples))
    n = len(samples)
    fade = min(200, n // 4)
    atk = min(30, n // 4)
    data = bytearray()
    for i, s in enumerate(samples):
        v = s / peak * gain
        if i < atk:
            v *= i / atk
        if i >= n - fade:
            v *= (n - i) / fade
        data += struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32767))
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(bytes(data))
    print("%-10s %6.2fs %6d bytes" % (name, n / SR, os.path.getsize(path)))


# ---------------- Банк 1: DRUMS ----------------
def kick():
    body = osc(0.45, lambda t: 45 + 110 * math.exp(-t * 22))
    body = env(body, lambda t: math.exp(-t * 7))
    click = env(highpass(noise(0.02)), lambda t: math.exp(-t * 200))
    return mix(body, [c * 0.3 for c in click])


def snare():
    tone = env(osc(0.3, lambda t: 190 - 40 * t), lambda t: math.exp(-t * 28))
    nz = env(highpass(noise(0.3)), lambda t: math.exp(-t * 16))
    return mix([x * 0.6 for x in tone], nz)


def hat_closed():
    return env(highpass(noise(0.09)), lambda t: math.exp(-t * 55))


def hat_open():
    return env(highpass(noise(0.4)), lambda t: math.exp(-t * 8))


def clap():
    n = noise(0.35)
    n = lowpass(highpass(n), 0.5)

    def f(t):
        bursts = sum(math.exp(-(t - b) * 90) for b in (0.0, 0.012, 0.025) if t >= b)
        return bursts + 0.5 * math.exp(-t * 14)

    return env(n, f)


def tom(f0):
    def freq(t):
        return f0 + f0 * 0.6 * math.exp(-t * 18)

    return env(osc(0.4, freq), lambda t: math.exp(-t * 8))


def cowbell():
    a = osc(0.35, lambda t: 540, square)
    b = osc(0.35, lambda t: 800, square)
    return env(lowpass(mix(a, b), 0.35), lambda t: math.exp(-t * 11))


# ---------------- Банк 2: SYNTH / FX ----------------
def bass():
    s = osc(0.7, lambda t: 55, saw)
    s = lowpass(mix(s, osc(0.7, lambda t: 55, sine)), 0.12)
    return env(s, lambda t: min(1.0, t * 80) * math.exp(-t * 4))


def stab():
    notes = (220.0, 261.63, 329.63, 392.0)  # Am7
    tracks = [osc(0.7, lambda t, f=f: f * (1 + 0.003 * math.sin(TAU * 5 * t)), saw) for f in notes]
    s = lowpass(mix(*tracks), 0.25)
    return env(s, lambda t: math.exp(-t * 6))


def pluck():
    s = osc(0.5, lambda t: 659.26, square)
    s = lowpass(s, 0.2)
    return env(s, lambda t: math.exp(-t * 9))


def laser():
    s = osc(0.4, lambda t: 200 + 2200 * math.exp(-t * 9))
    return env(s, lambda t: math.exp(-t * 5))


def scratch():
    def freq(t):
        return 350 + 300 * math.sin(TAU * 7 * t) + 120 * math.sin(TAU * 17 * t)

    s = osc(0.45, freq, saw)
    s = mix(s, [x * 0.4 for x in noise(0.45)])
    return env(lowpass(s, 0.3), lambda t: math.sin(math.pi * min(1.0, t / 0.45)) ** 0.5)


def riser():
    d = 1.3
    s = osc(d, lambda t: 200 + 1400 * (t / d) ** 2, saw)
    nz = highpass(noise(d))
    s = mix([x * 0.5 for x in s], [x * 0.5 for x in nz])
    return env(lowpass(s, 0.5), lambda t: (t / d) ** 1.5)


def crash():
    return env(highpass(noise(1.3)), lambda t: math.exp(-t * 3.2))


def airhorn():
    def f(base):
        return lambda t: base * (1 + 0.012 * math.sin(TAU * 6 * t))

    s = mix(osc(0.9, f(440), saw), osc(0.9, f(554.37), saw), osc(0.9, f(659.26), saw))
    s = lowpass(s, 0.22)
    return env(s, lambda t: min(1.0, t * 40) * (1.0 if t < 0.65 else math.exp(-(t - 0.65) * 12)))


# ---------------- Банк 3: HOUSE ----------------
def sub808():
    s = osc(1.0, lambda t: 41 + 25 * math.exp(-t * 25))
    return env(s, lambda t: math.exp(-t * 2.5))


def rim():
    tone = env(osc(0.12, lambda t: 1800), lambda t: math.exp(-t * 110))
    nz = env(highpass(noise(0.12)), lambda t: math.exp(-t * 90))
    return mix(tone, [x * 0.6 for x in nz])


def shaker():
    return env(highpass(noise(0.22)), lambda t: min(1.0, t / 0.02) * math.exp(-t * 22))


def conga():
    s = osc(0.35, lambda t: 280 + 70 * math.exp(-t * 30))
    return env(s, lambda t: math.exp(-t * 13))


def sweep():
    s = osc(0.9, lambda t: 200 + 2200 * math.exp(-t * 3.5), saw)
    return env(lowpass(s, 0.3), lambda t: math.exp(-t * 3))


def rev_crash():
    return list(reversed(crash()))


def chord():
    notes = (261.63, 329.63, 392.0, 493.88)  # Cmaj7
    s = mix(*[osc(1.2, lambda t, f=f: f * (1 + 0.002 * math.sin(TAU * 4 * t)), saw) for f in notes])
    return env(lowpass(s, 0.15), lambda t: min(1.0, t / 0.12) * math.exp(-t * 2.2))


def wobble():
    s = osc(0.8, lambda t: 55, saw)
    s = lowpass(s, 0.14)
    return env(s, lambda t: (0.55 + 0.45 * math.sin(TAU * 8 * t)) * math.exp(-t * 1.8))


if __name__ == "__main__":
    save("kick", kick())
    save("snare", snare())
    save("hat_c", hat_closed())
    save("hat_o", hat_open())
    save("clap", clap())
    save("tom_lo", tom(110))
    save("tom_hi", tom(190))
    save("cowbell", cowbell())

    save("bass", bass())
    save("stab", stab())
    save("pluck", pluck())
    save("laser", laser())
    save("scratch", scratch())
    save("riser", riser())
    save("crash", crash())
    save("airhorn", airhorn())

    save("sub808", sub808())
    save("rim", rim())
    save("shaker", shaker())
    save("conga", conga())
    save("sweep", sweep())
    save("rev", rev_crash())
    save("chord", chord())
    save("wobble", wobble())
